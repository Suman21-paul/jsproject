// public/js/script.js
console.log("JavaScript is loaded!");
